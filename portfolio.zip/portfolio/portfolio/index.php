<?php
require_once "header.php";
?>

        <!-- main-area -->
        <main>
              
            <!-- php code for about me -->

           <!-- you can find about me query  in side view part -->

            <!-- banner-area -->
            <section id="home" class="banner-area banner-bg fix">
                <div class="container">
                    <div class="row align-items-center">
                        <div class="col-xl-7 col-lg-6">
                            <div class="banner-content">
                                <h6 class="wow fadeInUp" data-wow-delay="0.2s">HELLO!</h6>
                                <?php
                                if($about_me['name']){
                                    ?>
                                <h2 style="font-size: 3em;" class="wow fadeInUp" data-wow-delay="0.4s">Welcome <?=$about_me['name']?> </h2><?php } ?>
                                <?php
                                if($about_me['intro']){
                                    ?>
                                <p class="wow fadeInUp" data-wow-delay="0.6s"><?=$about_me['intro']?></p><?php } ?>
                                <div class="banner-social wow fadeInUp" data-wow-delay="0.8s">
                                    <ul>
                                        <?php
                                        if($about_me['fb_link']){
                                            ?>
                                        <li><a  target="_blank" href="<?=$about_me['fb_link']?>"><i class="fab fa-facebook-f"></i></a></li><?php } ?>
                                            <?php
                                            if($about_me['twitter_link']){
                                                ?>
                                            <li><a target="_blank" href="<?=$about_me['twitter_link']?>"><i class="fab fa-twitter"></i></a></li><?php } ?>
                                                <?php
                                                if($about_me['linkedin_link']){
                                                    ?>
                                                <li><a target="_blank" href="<?=$about_me['linkedin_link']?>"><i class="fab fa-linkedin"></i></a></li><?php } ?>
                                                    <?php
                                                    if($about_me['github_link']){
                                                        ?>
                                                    <li><a target="_blank" href="<?=$about_me['github_link']?>"><i class="fab fa-github"></i></a></li><?php } ?>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="col-xl-5 col-lg-6 d-none d-lg-block">
                            <div class="banner-img text-right">
                                <img src="admin/image/profile/<?=$about_me['photo']?>" alt="">
                            </div>
                        </div>
                    </div>
                </div>
                <div class="banner-shape"><img src="front_end_assets/img/shape/dot_circle.png" class="rotateme" alt="img"></div>
            </section>
            <!-- banner-area-end -->
            <!-- about-area-->
            <section id="about" class="about-area primary-bg pt-120 pb-120">
                <div class="container">
                    <div class="row align-items-center">
                        <div class="col-lg-6">
                            <div class="about-img">
                                <img src="front_end_assets/img/banner/banner_img2.png" title="me-01" alt="me-01">
                            </div>
                        </div>
                        <div class="col-lg-6 pr-90">
                            <div class="section-title mb-25">
                                <span>Introduction</span>
                                <h2>About Us</h2>
                            </div>
                            <div class="about-content">
                                <p><?=$about_me['details']?></p>
                            </div>
                            <!-- End Education Item -->
                        </div>
                    </div>
                </div>
            </section>
            <!-- about-area-end -->
        </main>
        <!-- main-area-end -->

   <?php
require_once "footer.php";
?>