<?php 
session_start();
require_once "admin/db.php";
?>

<!doctype html>
<html class="no-js" lang="en">


<head>
        <meta charset="utf-8">
        <meta http-equiv="x-ua-compatible" content="ie=edge">
        <title>The Socialers</title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <link rel="shortcut icon" type="image/x-icon" href="front_end_assets/img/favicon.png">
        <!-- Place favicon.ico in the root directory -->

		<!-- CSS here -->
        <link rel="stylesheet" href="front_end_assets/css/bootstrap.min.css">
        <link rel="stylesheet" href="front_end_assets/css/animate.min.css">
        <link rel="stylesheet" href="front_end_assets/css/fontawesome-all.min.css">
        <link rel="stylesheet" href="front_end_assets/css/flaticon.css">
        <link rel="stylesheet" href="front_end_assets/css/default.css">
        <link rel="stylesheet" href="front_end_assets/css/style.css">
        <link rel="stylesheet" href="front_end_assets/css/responsive.css">
    </head>
    <body class="theme-bg">

        <!-- preloader -->
        <div id="preloader">
            <div id="loading-center">
                <div id="loading-center-absolute">
                    <div class="object" id="object_one"></div>
                    <div class="object" id="object_two"></div>
                    <div class="object" id="object_three"></div>
                </div>
            </div>
        </div>
        <!-- preloader-end -->

        <!-- header-start -->
        <header>
            <div id="header-sticky" class="transparent-header">
                <div class="container">
                    <div class="row">
                        <div class="col-xl-12">
                            <div class="main-menu">
                                <nav class="navbar navbar-expand-lg">
                                    <a href="index.php" class="navbar-brand logo-sticky-none"><img src="front_end_assets/img/logo/logo.png" alt="Logo"></a>
                                    <a href="index.php" class="navbar-brand s-logo-none"><img src="front_end_assets/img/logo/s_logo.png" alt="Logo"></a>
                                    <button class="navbar-toggler" type="button" data-toggle="collapse"
                                        data-target="#navbarNav">
                                        <span class="navbar-icon"></span>
                                        <span class="navbar-icon"></span>
                                        <span class="navbar-icon"></span>
                                    </button>
                                    <div class="collapse navbar-collapse" id="navbarNav">
                                        <ul class="navbar-nav ml-auto">
                                            <li class="nav-item active"><a class="nav-link" href="index.php">Home</a></li>
                                            <li class="nav-item"><a class="nav-link" href="about.php">about</a></li>
                                            <li class="nav-item"><a class="nav-link" href="contact.php">Contact</a></li>
                                            <li class="nav-item"><a class="nav-link" href="admin">Login</a></li>
                                        </ul>
                                    </div>
                                    <div class="header-btn">
                                        <a href="#" class="off-canvas-menu menu-tigger"><i class="flaticon-menu"></i></a>
                                    </div>
                                </nav>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- offcanvas-start -->
            <div class="extra-info">
                <div class="close-icon menu-close">
                    <button>
                        <i class="far fa-window-close"></i>
                    </button>
                </div>
                <div class="logo-side mb-30">
                    <a href="index.php">
                        <img src="front_end_assets/img/logo/logo.png" alt="site-logo" />
                    </a>
                </div>



                 <!--side view and contact information area  -->

                <?php 
                  $information_query = $dbcon->query("SELECT * FROM contact_information");
                  $contact_information = $information_query->fetch_assoc();
                ?>

                <!-- end contact information -->

                <!-- about me query start -->

                <?php 
                  $about_me_query = $dbcon->query("SELECT * FROM about_me");
                  $about_me = $about_me_query -> fetch_assoc();

                ?>

                <!-- about me query end  -->


                <div class="side-info mb-30">
                    <?php if ($contact_information['address']) {?>
                    <div class="contact-list mb-30">
                        <h4>Office Address</h4>
                        <p><?=$contact_information['address']?></p>
                    </div>
                    <?php }?>
                    <?php if ($contact_information['phone']) {?>
                    <div class="contact-list mb-30">
                        <h4>Phone Number</h4>
                        <p><a href="tel:<?=$contact_information['phone']?>"><?=$contact_information['phone']?></a></p>
                    </div>
                    <?php }?>
                    <?php if ($contact_information['email']) {?>
                    <div class="contact-list mb-30">
                        <h4>Email Address</h4>
                        <p><a href="mailto:<?=$contact_information['email']?>"><?=$contact_information['email']?></a></p>
                    </div>
                    <?php }?>
                </div>
                <div class="social-icon-right mt-20">

                        <?php
                        if($about_me['fb_link']){
                            ?>
                            <a  target="_blank" href="<?=$about_me['fb_link']?>"><i class="fab fa-facebook-f"></i></a>
                        <?php } ?>
                        <?php
                        if($about_me['twitter_link']){
                            ?>
                            <a target="_blank" href="<?=$about_me['twitter_link']?>"><i class="fab fa-twitter"></i></a>
                        <?php } ?>
                        <?php
                        if($about_me['linkedin_link']){
                            ?>
                            <a target="_blank" href="<?=$about_me['linkedin_link']?>"><i class="fab fa-linkedin"></i></a>
                        <?php } ?>
                        <?php
                        if($about_me['github_link']){
                            ?>
                            <a target="_blank" href="<?=$about_me['github_link']?>"><i class="fab fa-github"></i></a>
                        <?php } ?>

                </div>
            </div>
            <div class="offcanvas-overly"></div>
            <!-- offcanvas-end -->
        </header>