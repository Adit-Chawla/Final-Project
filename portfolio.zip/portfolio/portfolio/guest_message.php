<?php
session_start();
require_once "admin/db.php"; 
$name 	 = $_POST['guest_name'];
$email 	 = $_POST['guest_email'];
$message = $_POST['guest_message'];


if(!empty($name) && !empty($email) && !empty($message)){	
	$guest_message_insert = $dbcon->query("INSERT INTO guest_messages(name,email,message) VALUES ('$name','$email','$message')");
	$_SESSION['message_send'] = "Message sent successfully!";
	header('location: contact.php');



}else{
	$_SESSION['guest_message_error'] = "Fill all the fields correctly";
	header('location: contact.php');
}


?>