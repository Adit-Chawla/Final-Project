<?php
require_once "header.php";
?>
          <!-- about-area-->
            <section id="about" class="about-area primary-bg pt-120 pb-120">
                <div class="container">
                    <div class="row row text-center mt-4 mb-4">
                        <div class="col-md-12">
                            <h1>Little About</h1>
                        </div>
                    </div>
                    <div class="row align-items-center">
                        <div class="col-lg-6">
                            <div class="about-img">
                                <img src="admin/image/profile/<?=$about_me['photo']?>" alt="">
<!--                                <img src="front_end_assets/img/banner/banner_img2.png" title="me-01" alt="me-01">
-->                            </div>
                        </div>
                        <div class="col-lg-6 pr-90">
                            <div class="section-title mb-25">
                                <span>Introduction</span>
                                <h2>About </h2>
                            </div>
                            <div class="about-content">
                                <p><?=$about_me['details']?></p>
                                <h3>Statistics:</h3>
                            </div>

                          


                            <!-- Education Ite -->

                            <!-- php code for education -->

                            <?php 
                            $education_query = $dbcon->query("SELECT * FROM education_informations");
                            foreach ($education_query as $education) {
                            ?>





                            <div class="education">
                                <div class="year"><?=$education['year']?></div>
                                <div class="line"></div>
                                <div class="location">
                                    <span><?=$education['degree_name']?></span>
                                    <div class="progressWrapper">
                                        <div class="progress">
                                            <div class="progress-bar wow slideInLefts" data-wow-delay="0.2s" data-wow-duration="2s" role="progressbar" style="width: <?=$education['progressbar']?>%;" aria-valuenow="65" aria-valuemin="0" aria-valuemax="100"></div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <!-- end foreach -->
                          <?php } ?>
                            <!-- End Education Item -->
                            
                            <!-- End Education Item -->
                        </div>
                    </div>
                </div>
            </section>
            <!-- about-area-end -->

<?php
require_once "footer.php";
?> 