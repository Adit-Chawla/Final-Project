<?php 

const DB_HOST = '127.0.0.1';
const DB_USER = 'Adit200531948';
const DB_PASSWORD = '6ym96Kt8-R';
const DB_NAME = 'Adit200531948';

$dbcon = new mysqli(DB_HOST,DB_USER,DB_PASSWORD,DB_NAME);

if($dbcon->connect_error){
	die("Database connection failed".$dbcon->connect_error);
}

?>