<?php
require_once "header.php";
?>
       <!-- contact-area -->
            <section id="contact" class="contact-area primary-bg pt-120 pb-120">
                <div class="container">
                    <div class="row row text-center mt-4 mb-4">
                        <div class="col-md-12">
                            <h1>Contact Me</h1>
                        </div>
                    </div>
                    <div class="row align-items-center">

                       
               <!-- contact information query in side view part -->
                        

                        <div class="col-lg-6">
                            <div class="section-title mb-20">
                                <span>information</span>
                                <h2>Contact Information</h2>
                            </div>
                            <div class="contact-content">
                                <?php
                                if($contact_information['small_text']){
                                ?>
                                <p><?=$contact_information['small_text']?></p> <?php } ?>
                                        <?php
                                        if($contact_information['office']){
                                            ?>
                                <h5>OFFICE IN : <span><?=$contact_information['office']?></span></h5><?php } ?>
                                <div class="contact-list">
                                    <ul>
                                        <?php
                                        if($contact_information['address']){
                                            ?>
                                            <li><i class="fas fa-map-marker"></i><span>Address :</span><?=$contact_information['address']?></li> <?php } ?>
                                        <?php
                                        if($contact_information['phone']){
                                            ?>
                                            <li><i class="fas fa-headphones"></i><span>Phone :</span><a href="tel:<?=$contact_information['phone']?>"><?=$contact_information['phone']?></a></li> <?php } ?>
                                        <?php
                                        if($contact_information['email']){
                                            ?>
                                            <li><i class="fas fa-globe-asia"></i><span>e-mail :</span><a href="mailto:<?=$contact_information['email']?>"><?=$contact_information['email']?></a></li> <?php } ?>
                                    </ul>
                                </div>
                            </div>
                        </div>

                    <!-- contact information area end -->

                        <div class="col-lg-6">
                            <div class="contact-form">
                                <form action="guest_message.php" method="post">

                                  <!-- message send error  -->

                                  <?php if(isset($_SESSION['guest_message_error'])) { ?>
                                    <div class="alert alert-danger">
                                      <?=$_SESSION['guest_message_error']?>
                                    </div>
                                  <?php }
                                  // unset error message

                                  unset($_SESSION['guest_message_error']);
                                  ?>
                                  <!-- error end -->

                                  <!-- message send success -->

                                  <?php if(isset($_SESSION['message_send'])) { ?>
                                    <div class="alert alert-success">
                                      <?=$_SESSION['message_send']?>
                                    </div>
                                  <?php }
                                  // unset success message

                                  unset($_SESSION['message_send']);
                                  ?>

                                  <!-- end alert -->

                                    <input type="text" placeholder="your name *" name='guest_name'>
                                    <input type="email" placeholder="your email *" name='guest_email'>
                                    <textarea name="guest_message" id="message" placeholder="your message *"></textarea>
                                    <button class="btn">SEND</button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <!-- contact-area-end -->


<?php
require_once "footer.php";
?>