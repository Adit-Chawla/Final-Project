<?php
session_start();
require_once 'db.php'; 

$id = base64_decode($_GET['id']);
$dbcon->query("DELETE FROM users WHERE id=$id");
$_SESSION['user_delete'] = 'Delete Successfully!';
header('location: users.php');


?>