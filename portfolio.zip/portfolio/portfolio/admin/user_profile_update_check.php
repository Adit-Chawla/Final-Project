<?php
session_start();
require_once 'db.php';
ob_start();

$id = base64_decode($_GET['id']); 

if(isset($_POST['submit'])){
	$fname = $_POST['fname'];
	$email = $_POST['email'];
	$password = $_POST['password'];



	if(!empty($fname) && !empty($email) && !empty($password) ){
		$hash_password = password_hash($password, PASSWORD_BCRYPT);
		$user_update = $dbcon->query("UPDATE users SET fname='$fname',email='$email',password='$hash_password' WHERE id=$id");
		if($user_update){
		
			$_SESSION['user_update_success'] = "User Update Successfully!";
			header('location: users.php');
			ob_end_flush();
		} 
	}

}

// photo validation
if(isset($_POST['photo_submit'])){
	$photo      = $_FILES['photo']['name'];
	$photo_ext_array  = explode('.', $photo);
	$photo_ext = end($photo_ext_array);
	$photo_name =$id .".".$photo_ext;

	if(!empty($photo)){
		// if not empty
		if($_FILES['photo']['size']<5000000){
			// if photo in specific size
			$accepted_extension_list = ['png','jpg','jpeg'];
			if( in_array(strtolower($photo_ext),$accepted_extension_list) ){
				// remove present image
				$old_photo_query =$dbcon->query("SELECT photo FROM users WHERE id=$id");
				$old_photo = $old_photo_query->fetch_assoc();

				$photo_link = "image/users/".$old_photo['photo'];
				unlink($photo_link);

				// upload photo
				$update_photo =$dbcon->query("UPDATE users SET photo='$photo_name' WHERE id=$id");
				if($update_photo){
					move_uploaded_file($photo = $_FILES['photo']['tmp_name'],"image/users/". $photo_name);
					$_SESSION['user_photo_success'] = "Photo attached successfully!";
					header('location: user_profile_update.php?id=' . base64_encode($id));
					ob_end_flush();
				}


			}else{
				// if extension not match
				$_SESSION['user_photo_extension'] = "Atached a jpg,png or jpeg photo";
				header('location: user_profile_update.php?id=' . base64_encode($id));
				ob_end_flush();
			}

		}else{
			// if not in specific size
			$_SESSION['user_photo'] = "Attached a photo under 1MB";
			header('location: user_profile_update.php?id=' . base64_encode($id));
			ob_end_flush();
		}



	} else{
		// if empty
		$_SESSION['user_photo_empty'] = "Attached a Photo";
		header('location: user_profile_update.php?id=' . base64_encode($id));
		ob_end_flush();
	}

}

?>