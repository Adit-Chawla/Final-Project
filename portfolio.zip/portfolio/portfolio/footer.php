     <!-- footer -->
        <footer>
            <div class="copyright-wrap">
                <div class="container">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="col-md-4">
                                <a href="index.php" class="navbar-brand logo-sticky-none mb-4"><img src="front_end_assets/img/logo/logo.png" alt="Logo"></a>
                                <p><?=$about_me['details']?></p>
                            </div>
                            <div class="col-md-4">
                                <h3 class="mb-4">Social Links</h3>
                                <div class="social-links banner-social">
                                    <ul>
                                        <?php
                                        if($about_me['fb_link']){
                                            ?>
                                            <li><a  target="_blank" href="<?=$about_me['fb_link']?>"><i class="fab fa-facebook-f"></i></a></li><?php } ?>
                                        <?php
                                        if($about_me['twitter_link']){
                                            ?>
                                            <li><a target="_blank" href="<?=$about_me['twitter_link']?>"><i class="fab fa-twitter"></i></a></li><?php } ?>
                                        <?php
                                        if($about_me['linkedin_link']){
                                            ?>
                                            <li><a target="_blank" href="<?=$about_me['linkedin_link']?>"><i class="fab fa-linkedin"></i></a></li><?php } ?>
                                        <?php
                                        if($about_me['github_link']){
                                            ?>
                                            <li><a target="_blank" href="<?=$about_me['github_link']?>"><i class="fab fa-github"></i></a></li><?php } ?>
                                    </ul>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <h3 class="mb-4">Contact Me</h3>
                                <div class="footer_contact contact-list">
                                    <ul>
                                        <?php
                                        if($contact_information['address']){
                                        ?>
                                        <li><i class="fas fa-map-marker"></i><span>Address :</span><?=$contact_information['address']?></li> <?php } ?>
                                        <?php
                                        if($contact_information['phone']){
                                        ?>
                                        <li><i class="fas fa-headphones"></i><span>Phone :</span><a href="tel:<?=$contact_information['phone']?>"><?=$contact_information['phone']?></a></li> <?php } ?>
                                        <?php
                                        if($contact_information['email']){
                                        ?>
                                        <li><i class="fas fa-globe-asia"></i><span>e-mail :</span><a href="mailto:<?=$contact_information['email']?>"><?=$contact_information['email']?></a></li> <?php } ?>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                    <hr>
                    <div class="row align-items-center">
                        <div class="col-12">
                            <div class="copyright-text text-center">
                                © <?=date('Y')?> - All Rights Reserved
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </footer>
        <!-- footer-end -->





     <!-- JS here -->
     <script src="front_end_assets/js/vendor/jquery-1.12.4.min.js"></script>
  <script src="front_end_assets/js/ajax-form.js"></script>
     <script src="front_end_assets/js/wow.min.js"></script>
    <script src="front_end_assets/js/main.js"></script>
    </body>

</html>
